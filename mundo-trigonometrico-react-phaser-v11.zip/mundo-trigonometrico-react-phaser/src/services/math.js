export function normalize(text) {
  return String(text || "")
    .toLowerCase()
    .trim()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\s+/g, "");
}

export function normalizeMath(text) {
  return normalize(text)
    .replace(/cosecante/g, "csc")
    .replace(/secante/g, "sec")
    .replace(/cotangente/g, "cot")
    .replace(/coseno/g, "cos")
    .replace(/seno/g, "sen")
    .replace(/tangente/g, "tan")
    .replace(/sqrt\((\d+)\)/g, "√$1")
    .replace(/sqrt(\d+)/g, "√$1")
    .replace(/raizcuadradade/g, "√")
    .replace(/raizcuadrada/g, "√")
    .replace(/raizde/g, "√")
    .replace(/raiz/g, "√")
    .replace(/\^2/g, "²")
    .replace(/\*/g, "");
}

export function formatSeconds(seconds) {
  const value = Math.max(0, Number(seconds) || 0);
  if (value < 60) return `${value} s`;
  const minutes = Math.floor(value / 60);
  const rest = value % 60;
  return rest ? `${minutes} min ${rest} s` : `${minutes} min`;
}

export function fractionText(top, bottom) {
  return { top, bottom };
}

export function answerMatches(value, accepted = []) {
  const normalized = normalizeMath(value);
  return accepted.some((item) => normalized.includes(normalizeMath(item)));
}
