let audioCtx = null;
let musicTimer = null;

function context() {
  if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  return audioCtx;
}

export function tone(freq, duration = 0.12, type = "sine", volume = 0.04) {
  try {
    const audio = context();
    const osc = audio.createOscillator();
    const gain = audio.createGain();
    osc.type = type;
    osc.frequency.value = freq;
    gain.gain.value = volume;
    osc.connect(gain);
    gain.connect(audio.destination);
    osc.start();
    osc.stop(audio.currentTime + duration);
  } catch {
    return;
  }
}

export function playEffect(kind) {
  if (kind === "correct") {
    tone(660, 0.1, "triangle", 0.05);
    setTimeout(() => tone(880, 0.12, "triangle", 0.04), 90);
  }
  if (kind === "error") tone(180, 0.18, "sawtooth", 0.035);
  if (kind === "reward") [523, 659, 784, 1046].forEach((freq, index) => setTimeout(() => tone(freq, 0.11, "triangle", 0.045), index * 80));
}

export function setQuizMusic(enabled) {
  clearInterval(musicTimer);
  musicTimer = null;
  if (!enabled) return;
  const pattern = [392, 440, 523, 440, 587, 523];
  let index = 0;
  musicTimer = setInterval(() => {
    tone(pattern[index % pattern.length], 0.075, "square", 0.018);
    index += 1;
  }, 300);
}
