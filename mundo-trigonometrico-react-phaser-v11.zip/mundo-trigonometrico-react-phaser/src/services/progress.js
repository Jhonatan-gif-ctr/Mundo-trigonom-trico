import { zones } from "../data/zones.js";

export function createInitialProgress() {
  const zoneLives = Object.fromEntries(zones.map((zone) => [zone.id, 5]));
  return {
    xp: 0,
    reserveLives: 0,
    currentZoneIndex: 0,
    currentActivityIndex: 0,
    completed: [],
    attempts: {},
    records: [],
    grades: {},
    zoneLives,
    startAt: Date.now(),
    activityStartAt: Date.now()
  };
}

export function totalActivities() {
  return zones.reduce((total, zone) => total + zone.activities.length, 0);
}

export function maxXp() {
  return zones.reduce(
    (total, zone) => total + zone.activities.reduce((sum, activity) => sum + activity.xp, 0),
    0
  );
}

export function score100(progress) {
  const progressPart = (progress.completed.length / Math.max(1, totalActivities())) * 70;
  const xpPart = (progress.xp / Math.max(1, maxXp())) * 30;
  return Math.min(100, Math.round(progressPart + xpPart));
}

export function isZoneDone(zone, progress) {
  return zone.activities.length > 0 && zone.activities.every((activity) => progress.completed.includes(activity.id));
}

export function finalUnlocked(progress) {
  return zones.filter((zone) => !zone.final && !zone.construction).every((zone) => isZoneDone(zone, progress));
}

export function isZoneUnlocked(index, progress) {
  const zone = zones[index];
  if (zone.construction) return false;
  if (index === 0) return true;
  if (zone.final) return finalUnlocked(progress);
  const previousPlayable = zones.slice(0, index).filter((item) => !item.construction && !item.final).at(-1);
  return previousPlayable ? isZoneDone(previousPlayable, progress) : true;
}

export function levelDone(group, progress) {
  return group.activities.every((activity) => progress.completed.includes(activity.id));
}

export function levelUnlocked(groups, index, progress) {
  if (index === 0) return true;
  return groups.slice(0, index).every((group) => levelDone(group, progress));
}

export function buildRecord({ student, grade, zone, activity, result, progress, pasted }) {
  const attempts = progress.attempts[activity.id] || 0;
  const elapsed = Math.max(0, Math.floor((Date.now() - progress.activityStartAt) / 1000));
  const totalElapsed = Math.max(0, Math.floor((Date.now() - progress.startAt) / 1000));
  return {
    fecha: new Date().toLocaleString("es-PE"),
    estudiante: student,
    grado: grade,
    zona: zone.title,
    actividad: activity.title,
    reto: activity.id,
    nivel: activity.level,
    actividadEspecifica: activity.instruction,
    intentos: attempts + 1,
    tiempo: elapsed,
    tiempoTotalSimulador: totalElapsed,
    xp: result.ok ? activity.xp : 0,
    vidasZona: progress.zoneLives[zone.id],
    reserva: progress.reserveLives,
    pegoTexto: pasted ? "Sí" : "No",
    capacidad: activity.capacity,
    pensamientoComputacional: activity.ct,
    estado: result.ok ? "Logrado" : "En proceso"
  };
}

export function recordsToCsv(records) {
  const headers = [
    "fecha",
    "estudiante",
    "grado",
    "zona",
    "actividad",
    "reto",
    "nivel",
    "actividadEspecifica",
    "intentos",
    "tiempo",
    "tiempoTotalSimulador",
    "xp",
    "vidasZona",
    "reserva",
    "pegoTexto",
    "capacidad",
    "pensamientoComputacional",
    "estado"
  ];
  const escape = (value) => `"${String(value ?? "").replaceAll('"', '""')}"`;
  return [headers.join(","), ...records.map((record) => headers.map((key) => escape(record[key])).join(","))].join("\n");
}

export function downloadCsv(records) {
  const blob = new Blob(["\ufeff" + recordsToCsv(records)], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = "reporte-mundo-trigonometrico.csv";
  anchor.click();
  URL.revokeObjectURL(url);
}
