import { SHEETS_WEB_APP_URL } from "../data/config.js";

export async function sendProgressToSheets(payload) {
  if (!SHEETS_WEB_APP_URL) return { ok: false, skipped: true };
  const response = await fetch(SHEETS_WEB_APP_URL, {
    method: "POST",
    mode: "no-cors",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });
  return { ok: true, response };
}
