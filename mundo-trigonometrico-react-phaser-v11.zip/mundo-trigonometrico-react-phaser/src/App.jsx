import { useMemo, useState } from "react";
import { CAPACITIES, PUBLIC_URL, TEACHER_CODE } from "./data/config.js";
import { levelGroups, ratioLabels, ratioMap, zones } from "./data/zones.js";
import { rubric } from "./data/rubric.js";
import { sendProgressToSheets } from "./services/googleSheets.js";
import {
  buildRecord,
  createInitialProgress,
  downloadCsv,
  isZoneDone,
  isZoneUnlocked,
  levelDone,
  levelUnlocked,
  score100
} from "./services/progress.js";
import { answerMatches, formatSeconds } from "./services/math.js";
import { playEffect, setQuizMusic } from "./services/sound.js";
import PhaserGame from "./game/PhaserGame.jsx";

const screenNames = {
  login: "login",
  teacherLogin: "teacherLogin",
  welcome: "welcome",
  world: "world",
  levels: "levels",
  activity: "activity",
  teacher: "teacher"
};

function emptyStudent() {
  return { name: "", grade: "", avatar: "varon" };
}

export default function App() {
  const [screen, setScreen] = useState(screenNames.login);
  const [student, setStudent] = useState(emptyStudent);
  const [progress, setProgress] = useState(createInitialProgress);
  const [musicOn, setMusicOn] = useState(false);
  const [modal, setModal] = useState(null);
  const [teacherCode, setTeacherCode] = useState("");
  const [teacherTab, setTeacherTab] = useState("students");
  const [selectedStudent, setSelectedStudent] = useState("");
  const [pasted, setPasted] = useState(false);
  const [writtenAnswer, setWrittenAnswer] = useState("");
  const [sceneSolved, setSceneSolved] = useState(false);
  const [teacherGrades, setTeacherGrades] = useState({});

  const zone = zones[progress.currentZoneIndex];
  const activity = zone.activities[progress.currentActivityIndex] || zone.activities[0];
  const groups = useMemo(() => levelGroups(zone), [zone]);
  const currentLevelIndex = Math.max(
    0,
    groups.findIndex((group) => group.activities.some((item) => item.id === activity?.id))
  );

  function showWarmModal(kind, title, message, actions = [{ label: "Continuar" }]) {
    setModal({ kind, title, message, actions });
  }

  function closeModal(action) {
    setModal(null);
    if (action?.onClick) action.onClick();
  }

  function toggleMusic() {
    const next = !musicOn;
    setMusicOn(next);
    setQuizMusic(next);
  }

  function enterStudent() {
    if (!student.name.trim() || !student.grade.trim()) {
      showWarmModal("Datos incompletos", "Falta un pequeño paso", "Escribe nombres, apellidos y Grado/Sección para iniciar.");
      return;
    }
    setProgress(createInitialProgress());
    setScreen(screenNames.welcome);
  }

  function shareLink() {
    navigator.clipboard?.writeText(PUBLIC_URL);
    showWarmModal("Compartir", "Enlace copiado", "Ya puedes enviar el enlace del simulador a tus estudiantes.");
  }

  function teacherAccess() {
    if (teacherCode !== TEACHER_CODE) {
      showWarmModal("Acceso docente", "Clave incorrecta", "Verifica la clave docente e intenta nuevamente.");
      return;
    }
    setScreen(screenNames.teacher);
  }

  function openZone(index) {
    const target = zones[index];
    if (target.construction) {
      showWarmModal("Zona en construcción", "Todavía estamos afinando esta zona", "Primero consolidaremos las identidades recíprocas. Luego activaremos cociente.");
      return;
    }
    if (!isZoneUnlocked(index, progress)) {
      showWarmModal("Zona bloqueada", "Completa la ruta anterior", "Avanza en orden para mantener la construcción matemática paso a paso.");
      return;
    }
    setProgress((current) => ({ ...current, currentZoneIndex: index, currentActivityIndex: firstPendingIndex(target, current), activityStartAt: Date.now() }));
    setScreen(screenNames.levels);
  }

  function openLevel(index) {
    if (!levelUnlocked(groups, index, progress)) {
      showWarmModal("Nivel bloqueado", "Aún no toca ese tramo", "Termina primero todos los retos del nivel anterior.");
      return;
    }
    const firstPending = groups[index].activities.find((item) => !progress.completed.includes(item.id)) || groups[index].activities[0];
    setProgress((current) => ({
      ...current,
      currentActivityIndex: zone.activities.findIndex((item) => item.id === firstPending.id),
      activityStartAt: Date.now()
    }));
    resetActivityInputs();
    setScreen(screenNames.activity);
  }

  function resetActivityInputs() {
    setPasted(false);
    setWrittenAnswer("");
    setSceneSolved(false);
  }

  function validateActivity() {
    const validation = validateCurrent();
    const updatedAttempts = { ...progress.attempts, [activity.id]: (progress.attempts[activity.id] || 0) + 1 };
    const nextProgressBase = { ...progress, attempts: updatedAttempts };
    const record = buildRecord({ student: student.name, grade: student.grade, zone, activity, result: validation, progress: nextProgressBase, pasted });

    if (!validation.ok) {
      playEffect("error");
      const lives = Math.max(0, nextProgressBase.zoneLives[zone.id] - 1);
      const failedProgress = {
        ...nextProgressBase,
        zoneLives: { ...nextProgressBase.zoneLives, [zone.id]: lives },
        records: [...nextProgressBase.records, record]
      };
      if (lives <= 0) {
        const resetIds = new Set(zone.activities.map((item) => item.id));
        setProgress({
          ...failedProgress,
          completed: failedProgress.completed.filter((id) => !resetIds.has(id)),
          currentActivityIndex: 0,
          zoneLives: { ...failedProgress.zoneLives, [zone.id]: 5 },
          activityStartAt: Date.now()
        });
        showWarmModal("Reinicio de zona", "Respira y vuelve a construir", "Perdiste las vidas de esta zona. Solo se reinicia esta zona, tu ruta anterior se conserva.", [
          { label: "Volver al mapa de niveles", primary: true, onClick: () => setScreen(screenNames.levels) }
        ]);
        return;
      }
      setProgress(failedProgress);
      showWarmModal("Pista formativa", "Ajusta tu construcción", validation.message || `Te quedan ${lives} vidas en esta zona.`);
      return;
    }

    playEffect("correct");
    const completed = nextProgressBase.completed.includes(activity.id)
      ? nextProgressBase.completed
      : [...nextProgressBase.completed, activity.id];
    const gainedXp = nextProgressBase.completed.includes(activity.id) ? 0 : activity.xp;
    let nextProgress = {
      ...nextProgressBase,
      completed,
      xp: nextProgressBase.xp + gainedXp,
      records: [...nextProgressBase.records, record]
    };
    const wasLastInZone = zone.activities.every((item) => completed.includes(item.id));
    if (wasLastInZone) {
      const lives = nextProgress.zoneLives[zone.id];
      nextProgress = {
        ...nextProgress,
        reserveLives: lives === 5 ? nextProgress.reserveLives + 5 : nextProgress.reserveLives,
        zoneLives: { ...nextProgress.zoneLives, [zone.id]: Math.max(5, lives) }
      };
    }
    setProgress(nextProgress);

    const currentGroup = groups[currentLevelIndex];
    const groupComplete = currentGroup.activities.every((item) => completed.includes(item.id));
    const message = groupComplete
      ? "Completaste todos los retos de este nivel. Ahora el avatar puede avanzar al siguiente punto del mapa."
      : `Ganaste ${gainedXp} XP. El reto quedó registrado y puedes continuar construyendo.`;

    showWarmModal("Logro desbloqueado", validation.title || "¡Muy bien construido!", message, [
      { label: groupComplete ? "Ver mapa de niveles" : "Siguiente reto", primary: true, onClick: () => goNext(nextProgress) },
      { label: "Seguir explorando", onClick: () => setScreen(screenNames.activity) }
    ]);
    playEffect("reward");
  }

  function validateCurrent() {
    if (activity.scene === "written") {
      return answerMatches(writtenAnswer, activity.answerKeywords)
        ? { ok: true, title: "Tu explicación sí comunica la idea" }
        : { ok: false, message: "Tu respuesta debe mencionar la relación geométrica o el patrón que sostiene la identidad." };
    }
    if (["flow-verifier", "vault-cryptogram"].includes(activity.scene)) {
      const textOk = answerMatches(writtenAnswer, activity.answerKeywords);
      return sceneSolved && textOk
        ? { ok: true, title: "Construcción y argumento conectados" }
        : { ok: false, message: "Además de mover las piezas, escribe una justificación que mencione producto, 1 o recíprocas." };
    }
    return sceneSolved
      ? { ok: true, title: "La construcción encajó" }
      : { ok: false, message: "Manipula las piezas del ambiente hasta completar la relación antes de validar." };
  }

  function goNext(nextProgress) {
    const nextIndex = zone.activities.findIndex((item) => !nextProgress.completed.includes(item.id));
    if (nextIndex >= 0) {
      setProgress((current) => ({ ...current, currentActivityIndex: nextIndex, activityStartAt: Date.now() }));
      resetActivityInputs();
      setScreen(screenNames.activity);
      return;
    }
    setScreen(screenNames.levels);
  }

  async function sendProgress() {
    const payload = {
      student: student.name,
      grade: student.grade,
      score: score100(progress),
      totalSeconds: Math.max(0, Math.floor((Date.now() - progress.startAt) / 1000)),
      records: progress.records
    };
    try {
      await sendProgressToSheets(payload);
      showWarmModal("Progreso enviado", "Tu avance ya quedó registrado", "Puedes continuar trabajando o consultar tu nota cuando el docente la publique.");
    } catch {
      showWarmModal("Envío pendiente", "No se pudo conectar con Sheets", "Descarga o vuelve a intentar cuando tengas conexión.");
    }
  }

  function viewGrade() {
    const grade = teacherGrades[student.name];
    showWarmModal("Nota docente", "Resultado de evaluación", grade ? `Tu nota registrada es ${grade}/100.` : "Aún no hay nota registrada por el docente.");
  }

  const common = { student, setStudent, setScreen, shareLink, enterStudent, toggleMusic, musicOn };

  return (
    <>
      {screen === screenNames.login && <LoginScreen {...common} onTeacher={() => setScreen(screenNames.teacherLogin)} />}
      {screen === screenNames.teacherLogin && (
        <TeacherLogin
          code={teacherCode}
          setCode={setTeacherCode}
          onAccess={teacherAccess}
          onBack={() => setScreen(screenNames.login)}
        />
      )}
      {screen === screenNames.welcome && <WelcomeScreen student={student} onStart={() => setScreen(screenNames.world)} />}
      {screen === screenNames.world && (
        <WorldMap
          progress={progress}
          student={student}
          onOpenZone={openZone}
          onSend={sendProgress}
          onGrade={viewGrade}
          onMusic={toggleMusic}
          musicOn={musicOn}
        />
      )}
      {screen === screenNames.levels && (
        <LevelMap
          zone={zone}
          groups={groups}
          progress={progress}
          currentLevelIndex={currentLevelIndex}
          onOpenLevel={openLevel}
          onWorld={() => setScreen(screenNames.world)}
          onGrade={viewGrade}
        />
      )}
      {screen === screenNames.activity && activity && (
        <ActivityScreen
          zone={zone}
          activity={activity}
          progress={progress}
          student={student}
          musicOn={musicOn}
          writtenAnswer={writtenAnswer}
          setWrittenAnswer={setWrittenAnswer}
          setPasted={setPasted}
          setSceneSolved={setSceneSolved}
          onValidate={validateActivity}
          onLevels={() => setScreen(screenNames.levels)}
          onSend={sendProgress}
          onGrade={viewGrade}
          onMusic={toggleMusic}
        />
      )}
      {screen === screenNames.teacher && (
        <TeacherPanel
          records={progress.records}
          rubric={rubric}
          grades={teacherGrades}
          setGrades={setTeacherGrades}
          tab={teacherTab}
          setTab={setTeacherTab}
          selectedStudent={selectedStudent}
          setSelectedStudent={setSelectedStudent}
          onDownload={() => downloadCsv(progress.records)}
          onExit={() => setScreen(screenNames.login)}
        />
      )}
      {modal && <Modal modal={modal} onClose={closeModal} />}
    </>
  );
}

function firstPendingIndex(zone, progress) {
  const index = zone.activities.findIndex((activity) => !progress.completed.includes(activity.id));
  return Math.max(0, index);
}

function LoginScreen({ student, setStudent, enterStudent, shareLink, onTeacher }) {
  return (
    <main className="screen center-screen trig-bg">
      <section className="panel login-card">
        <p className="eyebrow">Simulador gamificado</p>
        <h1>MUNDO TRIGONOMÉTRICO</h1>
        <p className="lead">Construye, manipula, comprueba y argumenta identidades trigonométricas.</p>
        <label className="field">
          <span>Nombres y apellidos</span>
          <input value={student.name} onChange={(event) => setStudent({ ...student, name: event.target.value })} />
        </label>
        <label className="field">
          <span>Grado/Sección</span>
          <input value={student.grade} onChange={(event) => setStudent({ ...student, grade: event.target.value })} />
        </label>
        <div className="field">
          <span>Avatar</span>
          <div className="choice-row">
            <label><input type="radio" checked={student.avatar === "varon"} onChange={() => setStudent({ ...student, avatar: "varon" })} /> Explorador</label>
            <label><input type="radio" checked={student.avatar === "mujer"} onChange={() => setStudent({ ...student, avatar: "mujer" })} /> Exploradora</label>
          </div>
        </div>
        <div className="button-row">
          <button className="primary" onClick={enterStudent}>Entrar como estudiante</button>
          <button onClick={shareLink}>Compartir enlace</button>
          <button onClick={onTeacher}>Entrar como docente</button>
        </div>
      </section>
    </main>
  );
}

function TeacherLogin({ code, setCode, onAccess, onBack }) {
  return (
    <main className="screen center-screen trig-bg">
      <section className="panel login-card">
        <p className="eyebrow">Acceso docente</p>
        <h1>Panel docente</h1>
        <p className="lead">La clave no se muestra al estudiante. Solo el docente debe conocerla.</p>
        <label className="field">
          <span>Clave docente</span>
          <input type="password" value={code} onChange={(event) => setCode(event.target.value)} />
        </label>
        <div className="button-row">
          <button className="primary" onClick={onAccess}>Ingresar</button>
          <button onClick={onBack}>Volver</button>
        </div>
      </section>
    </main>
  );
}

function WelcomeScreen({ student, onStart }) {
  return (
    <main className="screen center-screen trig-bg">
      <section className="panel welcome-card">
        <p className="eyebrow">Bienvenida</p>
        <h1>¡Bienvenido, {student.name.split(" ")[0] || "estudiante"}!</h1>
        <p className="lead">Esta aventura no busca que memorices: busca que construyas, pruebes, expliques y mejores tus decisiones.</p>
        <div className="info-grid">
          <article><strong>Zonas bloqueadas</strong><span>Avanzas en orden para cuidar la progresión.</span></article>
          <article><strong>Vidas por zona</strong><span>Inicias cada zona con 5 vidas. Si las pierdes, se reinicia solo esa zona.</span></article>
          <article><strong>Bonificación</strong><span>Si terminas con 5 vidas intactas, acumulas 5 vidas extra para el reto final.</span></article>
          <article><strong>Envío de progreso</strong><span>Puedes enviar tu avance en cualquier momento.</span></article>
        </div>
        <p className="warning">Si cierras o recargas la página antes de enviar, podrías perder el progreso de esta sesión.</p>
        <button className="primary" onClick={onStart}>Comenzar aventura</button>
      </section>
    </main>
  );
}

function WorldMap({ progress, student, onOpenZone, onSend, onGrade, onMusic, musicOn }) {
  const currentPlayable = zones.findIndex((zone, index) => isZoneUnlocked(index, progress) && !isZoneDone(zone, progress));
  return (
    <main className="screen">
      <Topbar title="Mapa de aventura" subtitle="Ruta general del simulador" right={<>
        <button onClick={onMusic}>Música quiz: {musicOn ? "encendida" : "apagada"}</button>
        <span>{student.name} | Puntaje {score100(progress)}/100</span>
      </>} />
      <section className="map-shell panel">
        <div className="island-map">
          <svg viewBox="0 0 900 460" role="img" aria-label="Mapa de zonas">
            <path className="island" d="M76 242 C90 95 219 53 322 92 C414 18 585 48 640 139 C777 128 837 243 755 333 C674 425 509 392 439 419 C335 459 208 423 179 341 C101 342 58 300 76 242Z" />
            <path className="route" d="M155 280 C235 185 317 179 390 232 C467 286 563 138 657 192 C719 229 693 310 604 329 C510 349 395 329 306 369" />
          </svg>
          {zones.map((zone, index) => (
            <button
              key={zone.id}
              className={`map-node node-${index} ${isZoneUnlocked(index, progress) ? "open" : "locked"} ${isZoneDone(zone, progress) ? "done" : ""}`}
              onClick={() => onOpenZone(index)}
            >
              <span>{index + 1}</span>
              {zone.short}
              {currentPlayable === index && <Avatar gender={student.avatar} />}
            </button>
          ))}
        </div>
        <div className="button-row">
          <button className="primary" onClick={() => onOpenZone(Math.max(0, currentPlayable))}>Continuar ruta</button>
          <button onClick={onSend}>Enviar progreso</button>
          <button onClick={onGrade}>Ver nota</button>
        </div>
      </section>
    </main>
  );
}

function LevelMap({ zone, groups, progress, currentLevelIndex, onOpenLevel, onWorld, onGrade }) {
  return (
    <main className="screen">
      <Topbar title={zone.title} subtitle="Mapa interno por niveles" right={<>
        <button onClick={onWorld}>Mapa general</button>
        <button onClick={onGrade}>Ver nota</button>
      </>} />
      <section className="map-shell panel">
        <div className="level-map">
          <div className="level-route"></div>
          {groups.map((group, index) => (
            <button
              key={group.level}
              className={`level-node level-${index} ${levelUnlocked(groups, index, progress) ? "open" : "locked"} ${levelDone(group, progress) ? "done" : ""}`}
              onClick={() => onOpenLevel(index)}
            >
              <strong>{group.level}</strong>
              <span>{group.activities.filter((item) => progress.completed.includes(item.id)).length} de {group.activities.length} retos</span>
              {currentLevelIndex === index && <Avatar gender="varon" />}
            </button>
          ))}
        </div>
      </section>
    </main>
  );
}

function ActivityScreen({
  zone,
  activity,
  progress,
  student,
  musicOn,
  writtenAnswer,
  setWrittenAnswer,
  setPasted,
  setSceneSolved,
  onValidate,
  onLevels,
  onSend,
  onGrade,
  onMusic
}) {
  const elapsed = Math.max(0, Math.floor((Date.now() - progress.startAt) / 1000));
  const ratio = activity.ratio ? ratioLabels[activity.ratio] : "";
  return (
    <main className={`screen activity-screen zone-${zone.id}`}>
      <Topbar title="MUNDO TRIGONOMÉTRICO" subtitle={zone.title} right={<>
        <button onClick={onLevels}>Mapa de niveles</button>
        <button onClick={onMusic}>Música quiz: {musicOn ? "encendida" : "apagada"}</button>
        <span>{student.name} | XP {progress.xp} | Vidas {progress.zoneLives[zone.id]} | {formatSeconds(elapsed)}</span>
      </>} />
      <section className="activity-layout">
        <article className="panel activity-main">
          <p className="eyebrow">{activity.level}</p>
          <h1>{activity.title}</h1>
          <p className="lead">{activity.instruction}</p>
          {ratio && <p className="construct-target">Construye: <strong>{ratio}</strong></p>}
          <PhaserGame
            key={activity.id}
            zone={zone}
            activity={activity}
            onSolved={(solved) => setSceneSolved(solved)}
            onFeedback={(kind) => playEffect(kind)}
          />
          {["written", "flow-verifier", "vault-cryptogram"].includes(activity.scene) && (
            <label className="field argument-box">
              <span>Comunica y argumenta tu construcción</span>
              <textarea
                value={writtenAnswer}
                onPaste={() => setPasted(true)}
                onChange={(event) => setWrittenAnswer(event.target.value)}
                placeholder="Escribe tu explicación usando lenguaje matemático preciso."
              />
            </label>
          )}
          <div className="activity-actions">
            <button className="primary" onClick={onValidate}>Validar reto</button>
            <button onClick={onSend}>Enviar progreso</button>
            <button onClick={onGrade}>Ver nota docente</button>
            <button onClick={onLevels}>Cerrar actividad</button>
          </div>
        </article>
      </section>
    </main>
  );
}

function TeacherPanel({ records, rubric, grades, setGrades, tab, setTab, selectedStudent, setSelectedStudent, onDownload, onExit }) {
  const students = [...new Set(records.map((record) => record.estudiante))];
  const visibleRecords = selectedStudent ? records.filter((record) => record.estudiante === selectedStudent) : [];
  return (
    <main className="screen">
      <Topbar title="Panel docente" subtitle="Seguimiento, rúbrica y calificación" right={<button onClick={onExit}>Salir</button>} />
      <section className="teacher-layout">
        <div className="teacher-tabs">
          <button className={tab === "students" ? "primary" : ""} onClick={() => setTab("students")}>Estudiantes</button>
          <button className={tab === "rubric" ? "primary" : ""} onClick={() => setTab("rubric")}>Rúbrica y notas</button>
        </div>
        {tab === "students" && (
          <article className="panel">
            <h2>Lista de estudiantes</h2>
            <p className="lead">Primero aparece la lista. Luego puedes abrir el progreso individual.</p>
            <div className="student-list">
              {students.length === 0 && <p>Aún no hay registros en esta sesión.</p>}
              {students.map((name) => (
                <button key={name} onClick={() => setSelectedStudent(name)}>
                  {name} <span>Ver progreso</span>
                </button>
              ))}
            </div>
            {selectedStudent && <RecordsTable records={visibleRecords} />}
            <button onClick={onDownload}>Descargar reporte CSV de todos</button>
          </article>
        )}
        {tab === "rubric" && (
          <article className="panel">
            <h2>Rúbrica de evaluación</h2>
            <RubricTable rubric={rubric} />
            <h2>Calificar estudiantes</h2>
            {students.map((name) => (
              <label className="field grade-row" key={name}>
                <span>{name}</span>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={grades[name] || ""}
                  onChange={(event) => setGrades({ ...grades, [name]: event.target.value })}
                />
              </label>
            ))}
          </article>
        )}
      </section>
    </main>
  );
}

function RecordsTable({ records }) {
  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            <th>Zona</th>
            <th>Actividad</th>
            <th>Nivel</th>
            <th>Intentos</th>
            <th>Tiempo</th>
            <th>XP</th>
            <th>Estado</th>
          </tr>
        </thead>
        <tbody>
          {records.map((record, index) => (
            <tr key={`${record.reto}-${index}`}>
              <td>{record.zona}</td>
              <td>{record.actividad}</td>
              <td>{record.nivel}</td>
              <td>{record.intentos}</td>
              <td>{formatSeconds(record.tiempo)}</td>
              <td>{record.xp}</td>
              <td>{record.estado}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function RubricTable({ rubric }) {
  return (
    <div className="table-wrap">
      <table>
        <thead><tr><th>Dimensión</th><th>Criterio</th><th>Destacado</th></tr></thead>
        <tbody>
          {rubric.map((row) => (
            <tr key={row.dimension}>
              <td>{row.dimension}</td>
              <td>{row.criterio}</td>
              <td>{row.destacado}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Topbar({ title, subtitle, right }) {
  return (
    <header className="topbar">
      <div>
        <h1>{title}</h1>
        <p>{subtitle}</p>
      </div>
      <div className="top-actions">{right}</div>
    </header>
  );
}

function Avatar({ gender }) {
  return <span className={`avatar ${gender === "mujer" ? "female" : "male"}`} aria-hidden="true"><span></span></span>;
}

function Modal({ modal, onClose }) {
  return (
    <div className="modal-layer">
      <article className="modal-card">
        <p className="eyebrow">{modal.kind}</p>
        <h2>{modal.title}</h2>
        <p>{modal.message}</p>
        <div className="button-row">
          {modal.actions.map((action) => (
            <button key={action.label} className={action.primary ? "primary" : ""} onClick={() => onClose(action)}>
              {action.label}
            </button>
          ))}
        </div>
      </article>
    </div>
  );
}
