export const TEACHER_CODE = "PROFE-TRIGO-2026";
export const PUBLIC_URL = "https://jhonatan-gif-ctr.github.io/Mundo-trigonom-trico/";
export const SHEETS_WEB_APP_URL =
  "https://script.google.com/macros/s/AKfycbxU3uWIJTI9SP2ArxDlG5mT3iPqr1SIchDI_aB-TGtxFXgThpIaeuQCTp3VeEHcGeq5vQ/exec";

export const CAPACITIES = {
  modela: "Modela objetos con formas geométricas y sus transformaciones",
  comunica: "Comunica su comprensión sobre las formas y relaciones geométricas",
  estrategias: "Usa estrategias y procedimientos para orientarse en el espacio",
  argumenta: "Argumenta afirmaciones sobre relaciones geométricas"
};

export const CT = {
  descomposicion: "Descomposición",
  patrones: "Reconocimiento de patrones",
  abstraccion: "Abstracción",
  algoritmo: "Pensamiento algorítmico"
};
